/***************************** Include Files *********************************/
#include "xaxidma.h"
#include "xdebug.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xil_cache.h"
#include "xstatus.h"
#include "xil_types.h"
#include "xil_assert.h"
#include "xuartps_hw.h"
#include "xtmrctr.h"
#include "xil_mmu.h"

#include "MLP.h"
	
/***************** Macros *********************/
#define UART_BASEADDR		XPAR_XUARTPS_0_BASEADDR

#ifndef SDT
#define TMRCTR_DEVICE_ID	XPAR_TMRCTR_0_DEVICE_ID
#else
#define XTMRCTR_BASEADDRESS	XPAR_XTMRCTR_0_BASEADDR
#endif

#define TIMER_COUNTER_0	 0
#define DMA_DEV_ID_0 XPAR_AXIDMA_0_DEVICE_ID
#define DMA_DEV_ID_1 XPAR_AXIDMA_1_DEVICE_ID

/************************** Variable Definitions *****************************/
// ---------------------------------- DMA 0 ----------------------------------
u16 DeviceId0 = DMA_DEV_ID_0;
XAxiDma AxiDma0;					// Device instance
XAxiDma *InstancePtr0 = &AxiDma0; // Device pointer
// ---------------------------------- DMA 1 ----------------------------------
u16 DeviceId1 = DMA_DEV_ID_1;
XAxiDma AxiDma1;					// Device instance
XAxiDma *InstancePtr1 = &AxiDma1; // Device pointer

XTmrCtr TimerCounter;
XTmrCtr *TmrCtrInstancePtr = &TimerCounter;

/************************** Function Declarations *****************************/
int initialize_Timer();
int initialize_DMA();

/*****************************************************************************
 * Main function
 ******************************************************************************/
int main()
{
	int n;
	int success;

	/************************** Initializations *****************************/
	if (initialize_Timer() != XST_SUCCESS) {
		return 1;
	}

	if (initialize_DMA() != XST_SUCCESS) {
		return 1;
	}

	int size_X = N * FEATURES;
	int size_w_hid = WEIGHT_INPUT_SIZE * HIDDEN;
	int size_w_out = WEIGHT_OUTPUT_SIZE;
	memcpy(&merged_input[0], X, 4 * size_X);
	memcpy(&merged_input[size_X], w_hid, 4 * size_w_hid);
	memcpy(&merged_input[size_X + size_w_hid], w_out, 4 * size_w_out);

	// Xil_DCacheDisable(); // uncomment this as a last resort, which will avoid all cache related issues, but at the expense of performance.

	/************** Run a software version of the hardware function to validate results ************/

	int num_runs = 1000;
	xil_printf("%d runs for each type\r\n\r\n", num_runs);

	xil_printf("========= Testing on Software =========\r\n");

	time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	Soft_compute(num_runs);
	time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	xil_printf("Time elapsed during software computation : %d\r\n\r\n", (time1 - time0));

	/***************************** Interact with Coprocessor *****************************/

	 // ---------------------------------- CoProc 0 (HLS) ----------------------------------
	 xil_printf("====== Testing on CoProc 0 (HLS) ======\r\n");

	 time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	 CoProc_compute(InstancePtr0, result_HLS, num_runs);
	 time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	 int time_diff0 = time1 - time0;
	 xil_printf("Time elapsed during CoProc 0 computation : %d\r\n\r\n", time_diff0);

	 // ---------------------------------- CoProc 1 (HDL) ----------------------------------
	 xil_printf("====== Testing on CoProc 1 (HDL) ======\r\n");

	 time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	 CoProc_compute(InstancePtr1, result_HDL, num_runs);
	 time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	 int time_diff1 = time1 - time0;
	 xil_printf("Time elapsed during CoProc 1 computation : %d\r\n\r\n", time_diff1);

//	 xil_printf("CoProc 0 performance to CoProc_1 performance = %.3f\r\n\r\n", (float)(time_diff0 / time_diff1));

	/************************** Checking correctness of results *****************************/

	/****************************** SOFTWARE ******************************/
	success = 1;

	xil_printf("Comparing software computation results with labels ...\r\n");
	for (n = 0; n < N; n++) {
		success = success & (labels[n] == result_soft[n]);
		if (labels[n] != result_soft[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_soft[n], n);
		}
	} // Should be fine by here

	if (success != 1){
		xil_printf("Software computation test failed\r\n");
		return 1;
	}
	xil_printf("Software computation test succeeded\r\n\r\n");

	/*************************** HARDWARE (HLS) ***************************/
	xil_printf("Comparing hardware computation results (HLS) with labels ...\r\n");
	for (n = 0; n < N; n++) {
		success = success & (labels[n] == result_HLS[n]);
		if (labels[n] != result_HLS[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_HLS[n], n);
		}
	}

	if (success != 1){
		xil_printf("Hardware computation test failed (HLS)\r\n");
		return 1;
	}
	xil_printf("Hardware computation test succeeded (HLS)\r\n\r\n");

	/*************************** HARDWARE (HDL) ***************************/
	xil_printf("Comparing hardware computation results (HDL) with labels ...\r\n");
	for (n = 0; n < N; n++) {
		success = success & (labels[n] == result_HDL[n]);
		if (labels[n] != result_HDL[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_HDL[n], n);
		}
	}

	if (success != 1){
		xil_printf("Hardware computation test failed (HDL)\r\n");
		return 1;
	}
	xil_printf("Hardware computation test succeeded (HDL)\r\n\r\n");

	xil_printf("SUCCESS SUCCESS SUCCESS SUCCESS SUCCESS\r\n");

	return XST_SUCCESS;
}

int initialize_Timer() {
    // ---------------------------------- TIMER ----------------------------------
	/*
	 * Perform a self-test to ensure that the hardware was built
	 * correctly, use the 1st timer in the device (0)
	 */
	int Status;

#ifndef SDT
    Status = XTmrCtr_Initialize(TmrCtrInstancePtr, TMRCTR_DEVICE_ID);
#else
    Status = XTmrCtr_Initialize(TmrCtrInstancePtr, BaseAddr);
#endif
    if (Status != XST_SUCCESS) {
        xil_printf("XTmrCtr_Initialize failed.\r\n");
        return XST_FAILURE;
    }

    Status = XTmrCtr_SelfTest(TmrCtrInstancePtr, TIMER_COUNTER_0);
    if (Status != XST_SUCCESS) {
        xil_printf("XTmrCtr_SelfTest failed.\r\n");
        return XST_FAILURE;
    }

    /**
     * Enable the Autoreload mode of the timer counters.
	 * Up-counting by default, no reset value is needed
	 */
	XTmrCtr_SetOptions(TmrCtrInstancePtr, TIMER_COUNTER_0, XTC_AUTO_RELOAD_OPTION);

	time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	xil_printf("\r\nTimer initialized.\tTimer count: %d\r\n", time0);

	XTmrCtr_Start(TmrCtrInstancePtr, TIMER_COUNTER_0);

	time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	xil_printf("Timer started.\t\tTimer count: %d\r\n\r\n", time1);

    return XST_SUCCESS;
}

int initialize_DMA() {
    int Status;
    // ---------------------------------- DMA 0 ----------------------------------
	XAxiDma_Config *CfgPtr0;
	Status = XST_SUCCESS;

	/* Initialize the XAxiDma device.*/
	CfgPtr0 = XAxiDma_LookupConfig(DeviceId0);
	if (!CfgPtr0) {
		xil_printf("No config found for %d\r\n", DeviceId0);
		return XST_FAILURE;
	}
	xil_printf("Config found for %d\r\n", DeviceId0);

	Status = XAxiDma_CfgInitialize(&AxiDma0, CfgPtr0);
	if (Status != XST_SUCCESS) {
		xil_printf("Initialization failed %d\r\n", Status);
		return XST_FAILURE;
	}

	if (XAxiDma_HasSg(&AxiDma0)) {
		xil_printf("Device configured as SG mode \r\n");
		return XST_FAILURE;
	}

	/* Disable interrupts, we use polling mode */
	XAxiDma_IntrDisable(&AxiDma0, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DEVICE_TO_DMA);
	XAxiDma_IntrDisable(&AxiDma0, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DMA_TO_DEVICE);

	// ---------------------------------- DMA 1 ----------------------------------
	XAxiDma_Config *CfgPtr1;
	Status = XST_SUCCESS;

	/* Initialize the XAxiDma device.*/
	CfgPtr1 = XAxiDma_LookupConfig(DeviceId1);
	if (!CfgPtr1) {
		xil_printf("No config found for %d\r\n", DeviceId1);
		return XST_FAILURE;
	}
	xil_printf("Config found for %d\r\n", DeviceId1);

	Status = XAxiDma_CfgInitialize(&AxiDma1, CfgPtr1);
	if (Status != XST_SUCCESS) {
		xil_printf("Initialization failed %d\r\n", Status);
		return XST_FAILURE;
	}

	if (XAxiDma_HasSg(&AxiDma1)) {
		xil_printf("Device configured as SG mode \r\n");
		return XST_FAILURE;
	}

	/* Disable interrupts, we use polling mode */
	XAxiDma_IntrDisable(&AxiDma1, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DEVICE_TO_DMA);
	XAxiDma_IntrDisable(&AxiDma1, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DMA_TO_DEVICE);

	// For DMA
//	Xil_DCacheDisable(); // Uncomment this as a last resort, which will avoid all cache related issues, but at the expense of performance.

	return XST_SUCCESS;
}
