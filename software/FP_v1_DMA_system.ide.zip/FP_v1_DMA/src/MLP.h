#ifndef MLP_H
#define MLP_H

#include "xil_types.h"
#include "xaxidma.h"

#define TIMEOUT_VALUE 1 << 20 // timeout for FIFO reception

#define N 64
#define FEATURES 7
#define HIDDEN 2
#define OUTPUT 1
#define WEIGHT_INPUT_SIZE (FEATURES + 1)  // +1 for bias
#define WEIGHT_OUTPUT_SIZE (HIDDEN + 1)   // +1 for bias
#define TOTAL_WORDS (N * FEATURES + WEIGHT_INPUT_SIZE * HIDDEN + WEIGHT_OUTPUT_SIZE)

extern u32 X[N][FEATURES];

extern const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN];
extern const u32 w_out[WEIGHT_OUTPUT_SIZE];

extern u32 merged_input[TOTAL_WORDS];

extern const u8 labels[N];
extern u8 result_soft[N];
extern u8 result_HDL[N];
extern u8 result_HLS[N];

extern const u8 sigmoid_table[256];

u8 sigmoid(u16 x, const u8 *sigmoid_table);

u16 fixed_mul(u16 a, u16 b);

extern int time0, time1;

u8 mlp_predict(u32 input[FEATURES], const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN], const u32 w_out[WEIGHT_OUTPUT_SIZE], const u8 *sigmoid_table);
void computeResult(u32 X[N][FEATURES], u8 result[N], const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN], const u32 w_out[WEIGHT_OUTPUT_SIZE], const u8 *sigmoid_table);

int Soft_compute(int n);
int CoProc_compute(XAxiDma *InstancePtr, u8 result[], int n);

#endif // MLP_H
