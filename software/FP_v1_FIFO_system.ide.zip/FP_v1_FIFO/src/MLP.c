#include "xil_types.h"
#include "xstatus.h"
#include "xil_io.h"
#include "MLP.h"

#define NUMBER_OF_INPUT_NUMS (N * FEATURES + WEIGHT_INPUT_SIZE * HIDDEN + WEIGHT_OUTPUT_SIZE)

// Input data matrix
u32 X[N][FEATURES] = {
    {44, 90, 0, 0, 24, 81, 22},
    {159, 250, 140, 176, 121, 183, 138},
    {167, 158, 172, 134, 172, 161, 118},
    {130, 178, 136, 120, 135, 121, 86},
    {34, 112, 142, 112, 163, 159, 43},
    {63, 28, 145, 126, 190, 165, 66},
    {88, 214, 157, 140, 205, 174, 128},
    {185, 203, 170, 110, 211, 138, 126},
    {140, 255, 110, 136, 133, 156, 131},
    {73, 90, 164, 118, 75, 121, 111},
    {16, 93, 187, 88, 162, 101, 27},
    {31, 110, 120, 77, 166, 101, 45},
    {183, 181, 155, 175, 135, 211, 185},
    {129, 193, 104, 159, 184, 183, 161},
    {190, 183, 143, 124, 139, 138, 145},
    {79, 113, 115, 111, 164, 101, 88},
    {213, 213, 149, 159, 133, 199, 183},
    {13, 94, 127, 146, 132, 150, 89},
    {103, 175, 164, 139, 187, 147, 128},
    {42, 82, 104, 83, 167, 50, 71},
    {26, 90, 109, 143, 135, 220, 106},
    {69, 90, 101, 180, 125, 222, 108},
    {143, 225, 125, 147, 196, 197, 121},
    {73, 87, 125, 29, 8, 87, 67},
    {100, 136, 254, 119, 170, 140, 77},
    {110, 136, 101, 137, 186, 174, 126},
    {165, 143, 179, 151, 167, 156, 147},
    {182, 207, 131, 105, 130, 101, 124},
    {34, 51, 194, 94, 90, 94, 58},
    {108, 85, 116, 25, 24, 0, 59},
    {18, 70, 110, 118, 179, 138, 50},
    {35, 165, 120, 72, 126, 72, 82},
    {72, 99, 85, 76, 210, 101, 56},
    {27, 85, 85, 109, 122, 133, 54},
    {149, 166, 176, 111, 135, 115, 98},
    {138, 180, 136, 131, 255, 139, 84},
    {120, 97, 115, 96, 110, 128, 44},
    {183, 181, 183, 152, 119, 174, 148},
    {38, 113, 125, 67, 88, 26, 68},
    {180, 188, 169, 137, 188, 124, 145},
    {86, 87, 80, 72, 76, 73, 71},
    {219, 224, 155, 165, 197, 252, 218},
    {31, 65, 145, 38, 112, 32, 78},
    {21, 134, 48, 83, 94, 78, 111},
    {111, 62, 128, 89, 163, 209, 65},
    {224, 206, 128, 155, 167, 170, 150},
    {231, 225, 139, 174, 149, 202, 208},
    {140, 146, 106, 124, 192, 142, 104},
    {116, 191, 196, 136, 192, 170, 108},
    {43, 136, 131, 58, 44, 50, 118},
    {39, 76, 130, 63, 71, 62, 39},
    {103, 166, 170, 115, 236, 131, 75},
    {83, 148, 206, 120, 142, 156, 102},
    {73, 41, 150, 63, 123, 78, 51},
    {159, 136, 93, 153, 140, 149, 198},
    {14, 77, 160, 67, 68, 72, 56},
    {37, 70, 131, 53, 72, 46, 37},
    {225, 171, 136, 148, 136, 161, 188},
    {64, 177, 76, 69, 92, 92, 84},
    {44, 54, 166, 93, 158, 101, 59},
    {153, 170, 150, 125, 152, 171, 166},
    {86, 155, 136, 41, 36, 131, 63},
    {138, 160, 104, 119, 149, 124, 100},
    {19, 56, 140, 139, 217, 161, 51},
};

const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN] = {
	{26,6},
	{25,18},
	{31,6},
	{29,26},
	{22,1},
	{1,28},
	{11,9},
	{26,45}
};

const u32 w_out[WEIGHT_OUTPUT_SIZE] = {
	80,
	50,
	200,
};

const u8 labels[N] = {
    0, 1, 1, 1, 0, 0, 1, 1,
    1, 0, 0, 0, 1, 1, 1, 0,
    1, 0, 1, 0, 0, 1, 1, 0,
    1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 1, 1, 0, 1, 0, 1,
    0, 1, 0, 0, 1, 1, 1, 1,
    1, 0, 0, 1, 1, 0, 1, 0,
    0, 1, 0, 0, 1, 0, 1, 0,
};

u8 result_soft[N] = {0};
u8 result_HLS[N] = {0};
u8 result_HDL[N] = {0};

// Sigmoid LUT
const u8 sigmoid_table[256] = {
    12,12,12,12,13,13,13,14,14,14,15,15,15,16,16,16,17,17,18,18,18,19,19,20,20,21,21,21,22,22,23,23,24,24,25,26,26,27,27,28,28,29,30,30,31,32,32,33,34,34,35,36,36,37,38,39,39,40,41,42,43,44,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,66,67,68,69,70,72,73,74,75,76,78,79,80,82,83,84,86,87,88,90,91,92,94,95,97,98,99,101,102,104,105,107,108,110,111,113,114,116,117,119,120,122,123,125,126,128,129,130,132,133,135,136,138,139,141,142,144,145,147,148,150,151,153,154,156,157,158,160,161,163,164,165,167,168,169,171,172,173,175,176,177,179,180,181,182,183,185,186,187,188,189,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,211,212,213,214,215,216,216,217,218,219,219,220,221,221,222,223,223,224,225,225,226,227,227,228,228,229,229,230,231,231,232,232,233,233,234,234,234,235,235,236,236,237,237,237,238,238,239,239,239,240,240,240,241,241,241,242,242,242,243,243,243
};

INLINE u8 sigmoid(u16 x, const u8 *sigmoid_table) {
    if (x > 255) x = 255; // Impossible but here to make sure
    return sigmoid_table[x];
}

// Fixed-point multiply (0.8 format)
INLINE u16 fixed_mul(u16 a, u16 b) {
    return a * b;
}

int time0, time1;

// Core MLP compute for a single sample
u8 mlp_predict(u32 input[FEATURES], const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN], const u32 w_out[WEIGHT_OUTPUT_SIZE], const u8 *sigmoid_table) {
    u8 hidden[HIDDEN];
    for (int i = 0; i < HIDDEN; i++) {
        u32 sum = fixed_mul(256, w_hid[0][i]); // Bias
        for (int j = 0; j < FEATURES; j++) {
            sum += fixed_mul(input[j], w_hid[j + 1][i]);
        }
        hidden[i] = sigmoid(sum >> 8, sigmoid_table);
    }

    // Output layer: linear activation
    u16 out = fixed_mul(256, w_out[0]); // Bias
    for (int i = 0; i < HIDDEN; i++) {
        out += fixed_mul(hidden[i], w_out[i + 1]);
    }

    return (out >> 8) > 128 ? 1 : 0;
}

// Compute for all samples
void computeResult(u32 X[N][FEATURES], u8 result[N], const u32 w_hid[WEIGHT_INPUT_SIZE][HIDDEN], const u32 w_out[WEIGHT_OUTPUT_SIZE], const u8 *sigmoid_table) {
    for (int i = 0; i < N; i++) {
        result[i] = mlp_predict(X[i], w_hid, w_out, sigmoid_table);
    }
}

int Soft_compute(int n) {
	int countDownVal = n;
	while (countDownVal) {
		computeResult(X, result_soft, w_hid, w_out, sigmoid_table);
		countDownVal--;
	}
	return 0;
}

int CoProc_compute(XLlFifo *FifoInstancePtr, u8 result[], int n) {
	int word_cnt, countDownVal = n;
	int Status;
	while (countDownVal) {
		/************************** Transmit the Data Stream *****************************/

		XLlFifo_Reset(FifoInstancePtr);
//		XLlFifo_Start(FifoInstancePtr); // ensure it's started

		/* Writing into the FIFO Transmit Port Buffer */
		// A total of X + w_hid + w_out bytes
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < FEATURES; j++) {
				if (XLlFifo_iTxVacancy(FifoInstancePtr)) {
					XLlFifo_TxPutWord(FifoInstancePtr, X[i][j]);
				}
			}
		}
//		xil_printf("Finish X\r\n");

		for (int i = 0; i < WEIGHT_INPUT_SIZE; i++) {
			for (int j = 0; j < HIDDEN; j++) {
				if (XLlFifo_iTxVacancy(FifoInstancePtr)) {
					XLlFifo_TxPutWord(FifoInstancePtr, w_hid[i][j]);
				}
			}
		}
//		xil_printf("Finish w_hid\r\n");

		for (int i = 0; i < WEIGHT_OUTPUT_SIZE; i++) {
			if (XLlFifo_iTxVacancy(FifoInstancePtr)) {
				XLlFifo_TxPutWord(FifoInstancePtr, w_out[i]);
			}
		}
//		xil_printf("Finish w_out\r\n");

		/* Start Transmission by writing transmission length (number of bytes = 4* number of words) into the TLR */
		XLlFifo_iTxSetLen(FifoInstancePtr, NUMBER_OF_INPUT_NUMS * 4);
//		xil_printf("Tx Length Set\r\n");

		/* Check for Transmission completion */
		while (!(XLlFifo_IsTxDone(FifoInstancePtr))) {}
		/* Transmission Complete */
//		xil_printf("Transmission Complete\r\n");

		/************************** Receive the Data Stream *****************************/
//		xil_printf(" Receiving data...\r\n");

		// wait for coprocessor to send data, subject to a timeout
		int timeout_count = TIMEOUT_VALUE;
		while (!XLlFifo_iRxOccupancy(FifoInstancePtr)) {
//			u32 rx_occ = XLlFifo_iRxOccupancy(FifoInstancePtr);
//			xil_printf("RX Occupancy: %u\r\n", rx_occ);

			timeout_count--;
			if (timeout_count == 0) {
				xil_printf("Timeout while waiting for data ... \r\n");
				return XST_FAILURE;
			}
		}

		// we are expecting only one packet of data per test case. one packet = sequence of data until TLAST
		// if more packets are expected from the coprocessor, the part below should be done in a loop.
		u32 ReceiveLength = XLlFifo_iRxGetLen(FifoInstancePtr) / 4;
		for (word_cnt = 0; word_cnt < ReceiveLength; word_cnt++) {
			// read one word at a time
			result[word_cnt] = XLlFifo_RxGetWord(FifoInstancePtr);
		}

		Status = XLlFifo_IsRxDone(FifoInstancePtr);
		if (Status != TRUE) {
			xil_printf("Failing in receive complete ... \r\n");
			return XST_FAILURE;
		}
		/* Reception Complete */
		countDownVal--;
	}
	return 0;
}

