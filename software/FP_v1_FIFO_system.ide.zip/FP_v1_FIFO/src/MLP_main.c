/***************************** Include Files *********************************/
#include "xdebug.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xil_cache.h"
#include "xstatus.h"
#include "xil_types.h"
#include "xil_assert.h"
#include "xuartps_hw.h"
#include "xtmrctr.h"

#include "xllfifo.h"
#include "xstreamer.h"

#include "MLP.h"
	
/***************** Macros *********************/
#define UART_BASEADDR		XPAR_XUARTPS_0_BASEADDR

#ifndef SDT
#define TMRCTR_DEVICE_ID	XPAR_TMRCTR_0_DEVICE_ID
#else
#define XTMRCTR_BASEADDRESS	XPAR_XTMRCTR_0_BASEADDR
#endif

#define TIMER_COUNTER_0	 0

#define FIFO_DEV_ID_0 XPAR_AXI_FIFO_0_DEVICE_ID
#define FIFO_DEV_ID_1 XPAR_AXI_FIFO_1_DEVICE_ID

/************************** Variable Definitions *****************************/
// ---------------------------------- FIFO 0 ----------------------------------
XLlFifo FifoInstance0;
XLlFifo *FifoInstancePtr0 = &FifoInstance0;
// ---------------------------------- FIFO 1 ----------------------------------
XLlFifo FifoInstance1;
XLlFifo *FifoInstancePtr1 = &FifoInstance1;

XTmrCtr TimerCounter;
XTmrCtr *TmrCtrInstancePtr = &TimerCounter;

/************************** Function Declarations *****************************/
int initialize_Timer();
int initialize_AXIS_FIFO();

/*****************************************************************************
 * Main function
 ******************************************************************************/
int main()
{
	int n;
	int success;

	/************************** Initializations *****************************/
	if (initialize_Timer() != XST_SUCCESS) {
		return 1;
	}

	if (initialize_AXIS_FIFO() != XST_SUCCESS) {
		return 1;
	}

	/************** Run a software version of the hardware function to validate results ************/

	int num_runs = 1000;
	xil_printf("%d runs for each type\r\n\r\n", num_runs);

	xil_printf("========= Testing on Software =========\r\n");

	time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	Soft_compute(num_runs);
	time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	xil_printf("Time elapsed during software computation : %d\r\n\r\n", (time1 - time0));

	/***************************** Interact with Coprocessor *****************************/

	 // ---------------------------------- CoProc 0 (HLS) ----------------------------------
	 xil_printf("====== Testing on CoProc 0 (HLS) ======\r\n");

	 time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	 CoProc_compute(FifoInstancePtr0, result_HLS, num_runs);
	 time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	 int time_diff0 = time1 - time0;
	 xil_printf("Time elapsed during CoProc 0 computation : %d\r\n\r\n", time_diff0);

	 // ---------------------------------- CoProc 1 (HDL) ----------------------------------
	 xil_printf("====== Testing on CoProc 1 (HDL) ======\r\n");

	 time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
	 CoProc_compute(FifoInstancePtr1, result_HDL, num_runs);
	 time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);

	 int time_diff1 = time1 - time0;
	 xil_printf("Time elapsed during CoProc 1 computation : %d\r\n\r\n", time_diff1);

//	 xil_printf("CoProc 0 performance to CoProc_1 performance = %.3f\r\n\r\n", (float)(time_diff0 / time_diff1));

	/************************** Checking correctness of results *****************************/

	/****************************** SOFTWARE ******************************/
	success = 1;

	xil_printf("Comparing software computation results with labels ...\r\n");
	for (n = 0; n < N; n++)
	{
		success = success & (labels[n] == result_soft[n]);
		if (labels[n] != result_soft[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_soft[n], n);
		}
	} // Should be fine by here

	if (success != 1){
		xil_printf("Software computation test failed\r\n");
		return 1;
	}
	xil_printf("Software computation test succeeded\r\n\r\n");

	/*************************** HARDWARE (HLS) ***************************/
	xil_printf("Comparing hardware computation results (HLS) with labels ...\r\n");
	for (n = 0; n < N; n++)
	{
		success = success & (labels[n] == result_HLS[n]);
		if (labels[n] != result_HLS[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_HLS[n], n);
		}
	}

	if (success != 1){
		xil_printf("Hardware computation test failed (HLS)\r\n");
		return 1;
	}
	xil_printf("Hardware computation test succeeded (HLS)\r\n\r\n");

	/*************************** HARDWARE (HDL) ***************************/
	xil_printf("Comparing hardware computation results (HDL) with labels ...\r\n");
	for (n = 0; n < N; n++)
	{
		success = success & (labels[n] == result_HDL[n]);
		if (labels[n] != result_HDL[n]) {
			xil_printf("Mismatch found: %d and %d @ word_cnt = %d\r\n", labels[n], result_HDL[n], n);
		}
	}

	if (success != 1){
		xil_printf("Hardware computation test failed (HDL)\r\n");
		return 1;
	}
	xil_printf("Hardware computation test succeeded (HDL)\r\n\r\n");

	xil_printf("SUCCESS SUCCESS SUCCESS SUCCESS SUCCESS\r\n");

	return XST_SUCCESS;
}

int initialize_Timer() {
    // ---------------------------------- TIMER ----------------------------------
	/*
	 * Perform a self-test to ensure that the hardware was built
	 * correctly, use the 1st timer in the device (0)
	 */
	int Status;

#ifndef SDT
    Status = XTmrCtr_Initialize(TmrCtrInstancePtr, TMRCTR_DEVICE_ID);
#else
    Status = XTmrCtr_Initialize(TmrCtrInstancePtr, BaseAddr);
#endif
    if (Status != XST_SUCCESS) {
        xil_printf("XTmrCtr_Initialize failed.\r\n");
        return XST_FAILURE;
    }

    Status = XTmrCtr_SelfTest(TmrCtrInstancePtr, TIMER_COUNTER_0);
    if (Status != XST_SUCCESS) {
        xil_printf("XTmrCtr_SelfTest failed.\r\n");
        return XST_FAILURE;
    }

    /**
     * Enable the Autoreload mode of the timer counters.
     * Up-counting by default, no reset value is needed
     */
    XTmrCtr_SetOptions(TmrCtrInstancePtr, TIMER_COUNTER_0, XTC_AUTO_RELOAD_OPTION);

    time0 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
    xil_printf("\r\nTimer initialized.\tTimer count: %d\r\n", time0);

    XTmrCtr_Start(TmrCtrInstancePtr, TIMER_COUNTER_0);

    time1 = XTmrCtr_GetValue(TmrCtrInstancePtr, TIMER_COUNTER_0);
    xil_printf("Timer started.\t\tTimer count: %d\r\n\r\n", time1);

    return XST_SUCCESS;
}

int initialize_AXIS_FIFO() {
    int Status;
    // ---------------------------------- FIFO 0 ----------------------------------
	XLlFifo_Config *Config0;

	/* Initialize the Device Configuration Interface driver */
	Config0 = XLlFfio_LookupConfig(FIFO_DEV_ID_0);
	if (!Config0)
	{
		xil_printf("No config found for %d\r\n", FIFO_DEV_ID_0);
		return XST_FAILURE;
	}

	Status = XLlFifo_CfgInitialize(FifoInstancePtr0, Config0, Config0->BaseAddress);
	if (Status != XST_SUCCESS)
	{
		xil_printf("Initialization failed\r\n");
		return XST_FAILURE;
	}

	/* Check for the Reset value */
	Status = XLlFifo_Status(FifoInstancePtr0);
	XLlFifo_IntClear(FifoInstancePtr0, 0xffffffff);
	Status = XLlFifo_Status(FifoInstancePtr0);
	if (Status != 0x0)
	{
		xil_printf("\n ERROR : Reset value of ISR0 : 0x%x\t. Expected : 0x0\r\n",
				   XLlFifo_Status(FifoInstancePtr0));
		return XST_FAILURE;
	}

	// ---------------------------------- FIFO 1 ----------------------------------
	XLlFifo_Config *Config1;

	/* Initialize the Device Configuration Interface driver */
	Config1 = XLlFfio_LookupConfig(FIFO_DEV_ID_1);
	if (!Config1)
	{
		xil_printf("No config found for %d\r\n", FIFO_DEV_ID_1);
		return XST_FAILURE;
	}

	Status = XLlFifo_CfgInitialize(FifoInstancePtr1, Config1, Config1->BaseAddress);
	if (Status != XST_SUCCESS)
	{
		xil_printf("Initialization failed\r\n");
		return XST_FAILURE;
	}

	/* Check for the Reset value */
	Status = XLlFifo_Status(FifoInstancePtr1);
	XLlFifo_IntClear(FifoInstancePtr1, 0xffffffff);
	Status = XLlFifo_Status(FifoInstancePtr1);
	if (Status != 0x0)
	{
		xil_printf("\n ERROR : Reset value of ISR0 : 0x%x\t. Expected : 0x0\r\n",
				   XLlFifo_Status(FifoInstancePtr1));
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}
